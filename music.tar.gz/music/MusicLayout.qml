/******************************************************************
Copyright © Deng Zhimao Co., Ltd. 2021-2030. All rights reserved.
* @projectName   music
* @brief         MusicLayout.qml
* @author        Deng Zhimao
* @email         dengzhimao@alientek.com/1252699831@qq.com
* @link          www.openedv.com
* @date          2024-05-04
*******************************************************************/
import QtQuick 2.12
import QtMultimedia 5.0
import QtQuick.Controls 2.5
import com.alientek.qmlcomponents 1.0
import QtQuick.Layouts 1.12
Item {
    id: musicLayout
    anchors.fill: parent
    property int lyric_CurrtentIndex: -1
    property int control_duration: 0
    signal playBtnSignal()
    signal previousBtnSignal()
    signal nextBtnSignal()
    signal playProgressChanged(real playProgress)
    property int progress_maximumValue: 0
    property bool progress_pressed: false
    property int progress_value: 0
    property int music_loopMode: 2
    property real scaleFacter: musicLayout.width / 1024

    function currentMusicTime(time){
        if (!loader.enabled)
            return
        var sec = Math.floor(time / 1000);
        var hours = Math.floor(sec / 3600);
        var minutes = Math.floor((sec - hours * 3600) / 60);
        var seconds = sec - hours * 3600 - minutes * 60;
        var hh, mm, ss;
        if(hours.toString().length < 2)
            hh = "0" + hours.toString();
        else
            hh = hours.toString();
        if(minutes.toString().length < 2)
            mm="0" + minutes.toString();
        else
            mm = minutes.toString();
        if(seconds.toString().length < 2)
            ss = "0" + seconds.toString();
        else
            ss = seconds.toString();
        return /*hh+":"*/ + mm + ":" + ss
    }

    onPlayBtnSignal: {
        if (playList.musicCount === 0)
            return
        if (music_playlistModel.currentIndex !== -1) {
            musicPlayer.source =  music_playlistModel.getcurrentPath()
            playList.music_currentIndex = music_playlistModel.currentIndex
            playList.musicName = music_playlistModel.getcurrentSongName()
            musicPlayer.playbackState === MediaPlayer.PlayingState ? musicPlayer.pause() : musicPlayer.play()
        }
    }

    onPreviousBtnSignal: {
        switch (music_loopMode) {
        case 0:
        case 1:
        case 2:
            music_playlistModel.currentIndex--
            musicPlayer.play()
            break;
        case 3:
            music_playlistModel.randomIndex();
            musicPlayer.play()
            break;
        }
    }

    onNextBtnSignal: {
        if (musicPlayer.hasAudio)
            switch (music_loopMode) {
            case 0:
            case 1:
            case 2:
                music_playlistModel.currentIndex++
                musicPlayer.play()
                break;
            case 3:
                music_playlistModel.randomIndex()
                musicPlayer.play()
                break;
            }
    }

    LyricModel {
        id: music_lyricModel
    }

    PlayListModel {
        id: music_playlistModel
        currentIndex: 0
        onCurrentIndexChanged: {
            musicPlayer.source = getcurrentPath()
            musicPlayer.play() // ???
        }

        onSongNameChanged: {
            music_lyricModel.setPathofSong(music_playlistModel.songName, appCurrtentDir)
        }
        Component.onCompleted: {
            songsInit()
        }
    }

    Connections {
        target: musicPlayer
        onPositionChanged: {
            if (!loader.enabled)
                return
            progress_maximumValue = musicPlayer.duration
            if(!progress_pressed) {
                progress_value = musicPlayer.position
                playProgressChanged(musicPlayer.position / musicPlayer.duration)
            }
        }
        onPlaybackStateChanged: {
            switch (musicPlayer.playbackState) {
            case MediaPlayer.PlayingState:
                break;
            case MediaPlayer.PausedState:
            case MediaPlayer.StoppedState:
                break;
            default:
                break;
            }
        }
        onStatusChanged: {
            switch (musicPlayer.status) {
            case MediaPlayer.NoMediaMedia:
                break;
            case MediaPlayer.LoadingMedia:
                break;
            case MediaPlayer.LoadedMedia:
                progress_maximumValue = musicPlayer.duration
                break;
            case MediaPlayer.BufferingMedia:
                break;
            case MediaPlayer.StalledMedia:
                break;
            case MediaPlayer.BufferedMedia:
                break;
            case MediaPlayer.InvalidMediaMedia:
                switch (musicPlayer.error) {
                case MediaPlayer.FormatError:
                    ttitle.text = qsTr("需要安装解码器");
                    break;
                case MediaPlayer.ResourceError:
                    ttitle.text = qsTr("文件错误");
                    break;
                case MediaPlayer.NetworkError:
                    ttitle.text = qsTr("网络错误");
                    break;
                case MediaPlayer.AccessDenied:
                    ttitle.text = qsTr("权限不足");
                    break;
                case MediaPlayer.ServiceMissing:
                    ttitle.text = qsTr("无法启用多媒体服务");
                    break;
                }
                break;
            case MediaPlayer.EndOfMedia:
                musicPlayer.autoPlay = true
                music_lyricModel.currentIndex = 0
                progress_maximumValue = 0
                progress_value = 0
                switch (music_loopMode) {
                case 1:
                    musicPlayer.play()
                    break;
                case 2:
                    music_playlistModel.currentIndex++
                    break;
                case 3:
                    music_playlistModel.randomIndex()
                    break;
                default:
                    break;
                }
                break;
            }
        }
    }
    Connections {
        target: music_playlistModel
        onCurrentIndexChanged: {
            playList.music_currentIndex = music_playlistModel.currentIndex
            playList.musicName = music_playlistModel.songName
        }
    }

    Connections {
        target: playList
        onMusicNameChanged: {
            music_lyricModel.setPathofSong(playList.musicName, appCurrtentDir)
            artBg.source = "file://" + appCurrtentDir + "/resource/artist/" + playList.musicName
        }
    }

    Audio {
        id: musicPlayer
        source: ""
        volume: 1
        objectName: "myAudio"
        autoPlay: false
        onSourceChanged: {
            music_lyricModel.setPathofSong(source, appCurrtentDir);
        }
    }

    function songsInit(){
        music_playlistModel.add(appCurrtentDir)
    }

    RowLayout {
        z: 10
        anchors.fill: parent
        spacing: 25
        AlbumImage {
            Layout.leftMargin: 50
            id: art_album
            //x:  musicPlayer.playbackState === MediaPlayer.PlayingState ? parent.width / 5 : parent.width / 5 + art_album.width / 4
            width: musicLayout.height / 1.5
            height: width
            radius: 15
            source: artBg.source
            visible: true
        }
        Item {
            Layout.rightMargin: 50
            Layout.fillWidth: true
            height: art_album.height
            Item {
                anchors.fill: parent
                PlayPanel {id: playPanel}
                PlayList {
                    id: playList
                    visible: !playPanel.visible
                    anchors.centerIn: parent
                    width: parent.width
                    height: parent.height + 25
                }
            }
        }
    }

    BlurImage {
        id: artBg
        width: musicLayout.width
        height: musicLayout.height
        source: "file://" + appCurrtentDir + "/resource/artist/default.jpg"
        Rectangle {
            opacity: 0.8
            color: "black"
            anchors.fill: parent
        }
        radius: 100
    }

    /* Item {
        id: music_playlist_dawer_bottom
        width: parent.width
        height: parent.height
        z: 51
        MouseArea {anchors.fill: parent}
        x: 0
        y: height
        Behavior on y { PropertyAnimation { duration: control_duration; easing.type: Easing.OutQuad } }

        MouseArea {
            anchors.fill: parent
            drag.target: parent
            drag.minimumX: 0
            drag.minimumY: 0
            drag.maximumX: 0
            drag.maximumY: parent.height
            property int dragY
            onPressed: {
                dragY = parent.y
            }
            onReleased: {
                if (parent.y - dragY >= 100)
                    music_playlist_dawer_bottom.close()
                else
                    music_playlist_dawer_bottom.open()
            }
        }

        PlayList {
            id: playList
            anchors.fill: parent
        }

        function open() {
            control_duration = 200
            music_playlist_dawer_bottom.y = 0
        }

        function close() {
            music_playlist_dawer_bottom.y = height
        }
    }*/

    Button {
        id: playListBt
        z: 11
        width: 64 * scaleFactor
        height: width
        anchors.right: parent.right
        anchors.rightMargin: 10
        anchors.bottom: parent.bottom
        anchors.bottomMargin: 10
        opacity: playListBt.pressed ? 0.5 : 1.0
        checkable: true
        checked: false
        background: Rectangle {
            width: 50 * scaleFactor
            height: width
            radius: 10
            color: playListBt.checked ? "#94a2c6" : "transparent"
            Image {
                source: "qrc:/icons/btn_playlist.png"
                width: 30 * scaleFactor
                height: width
                anchors.centerIn: parent
            }
        }
        onCheckedChanged: {
            playPanel.visible = !playListBt.checked
        }
    }

    Button {
        z: 11
        id: broadcatingBt
        anchors.left: parent.left
        anchors.leftMargin: 10
        width: 64 * scaleFactor
        height: width
        anchors.bottom: parent.bottom
        anchors.bottomMargin: 10
        //opacity: broadcatingBt.pressed ? 0.5 : 1.0
        background: Image {
            source: "qrc:/icons/broadcasting_station.png"
            width: 40 * scaleFactor
            height: width
            anchors.centerIn: parent
            Text {
                text: playList.musicName === "" ?  qsTr("小原的 Solo Pro") : playList.musicName
                color: "white"
                font.pixelSize: 20 * scaleFactor
                anchors.left: parent.right
                anchors.leftMargin: 10
                anchors.verticalCenter: parent.verticalCenter
            }
        }
    }
}
